package com.example.ano

import android.annotation.SuppressLint
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ano.model.AnoViewModel
import com.example.ano.ui.DictionaryDefinitionScreen
import com.example.ano.ui.DictionarySearchingScreen
import com.example.ano.ui.FavoritesScreen
import com.example.ano.ui.HistoryScreen
import com.example.ano.ui.HomePageScreen
import com.example.readinggoals.ui.theme.Barlow


enum class AnoScreen(@StringRes val title :Int ){
    Homepage(title = R.string.app_name),
    Dictionary(title = R.string.dictionary),
    Searching(title = R.string.dictionary),
    Favorites(title= R.string.favorites),
    History(title= R.string.histrory),
    Test(title=R.string.app_name)
}

// TODO: AppBar
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnoAppBar(
    currentScreen: AnoScreen,
    canNavigateBack: Boolean,
    navigateUp: () -> Unit,
    modifier: Modifier = Modifier
){
    CenterAlignedTopAppBar(
        title = { Text(
            text =stringResource(id = currentScreen.title),
            fontFamily = Barlow,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            )},
        colors = TopAppBarDefaults.mediumTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        ),
        modifier = modifier,
        navigationIcon = {
            if(canNavigateBack){
                IconButton(onClick = navigateUp) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Back"
                    )

                }
            }
        }
    )
}

@SuppressLint("SuspiciousIndentation")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnoApp() {
    val navController = rememberNavController()
    // Create ViewModel
    val viewModel: AnoViewModel = viewModel()
    // Get current back stack entry
    val backStackEntry by navController.currentBackStackEntryAsState()
    // Get the name of the current screen
    val currentScreen = AnoScreen.valueOf(
        backStackEntry?.destination?.route ?: AnoScreen.Homepage.name
    )
    Scaffold(
        topBar = {
            AnoAppBar(
                currentScreen = currentScreen,
                canNavigateBack = navController.previousBackStackEntry !=null,
                navigateUp = { navController.navigateUp() })
        }
    ) { innerPadding ->

        val uiState by viewModel.uiState.collectAsState()

        NavHost(
            navController=navController,
            startDestination =AnoScreen.Homepage.name,
            modifier = Modifier.padding(innerPadding)
        ){
            composable(route = AnoScreen.Homepage.name){
                HomePageScreen(
                    onDictionaryButtonClicked = { navController.navigate(AnoScreen.Searching.name) },
                    onFavoriteButtonClicked = { navController.navigate(AnoScreen.Favorites.name) },
                    onHistoryButtonClicked = { navController.navigate(AnoScreen.History.name) }
                )
            }
            composable(route = AnoScreen.Searching.name){
                DictionarySearchingScreen(
                    searchWord = viewModel.searchWord,
                    onUserSearchedChanged ={
                        viewModel.updateSearchedWord(it)
                    },
                    onKeyboardSearch = {
                        viewModel.onKeyboardSearch()
                        if(viewModel.isWordInDico()) navController.navigate(AnoScreen.Dictionary.name)}
                )
            }
            composable(route = AnoScreen.Dictionary.name){
                DictionaryDefinitionScreen(
                    isFavorite= { viewModel.isFavoriteWord(it) },
                    word = viewModel.currentWord,
                    wordInfos =viewModel.infoCurrentWord,
                    onFavoriteButtonClicked ={viewModel.onFavoriteButtonClicked()}
                )
            }
            composable(route = AnoScreen.Favorites.name){
                FavoritesScreen(
                    isFavorite = {viewModel.isFavoriteWord(it)},
                    words = uiState.favorites,
                    onFavoriteButtonClicked = { viewModel.onFavoriteButtonClickedList(it)},
                    onWordClicked = { viewModel.onWordClicked(it)
                        navController.navigate(AnoScreen.Dictionary.name)})
            }
            composable(route = AnoScreen.History.name){
                HistoryScreen(
                    isFavorite = {viewModel.isFavoriteWord(it)},
                    words = uiState.wordsInHistory,
                    onFavoriteButtonClicked = { viewModel.onFavoriteButtonClickedList(it)},
                    onWordClicked = { viewModel.onWordClicked(it)
                        navController.navigate(AnoScreen.Dictionary.name)}
                )
            }
        }
    }
}



