package com.example.ano.dataSource
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.io.File


@Serializable
data class InfoDefinitions(
    val lexique: String?,
    val exemples: List<String>
)

@Serializable
data class InformationWordByNature(
    val nature: String,
    val definitions: Map<String, InfoDefinitions>,
    val synonymes: List<String>?,
    val derives: List<String>,
    var isFavorite : Boolean = false
)

object DataSource {
    val jsonString = File("/Users/laura/Documents/Informatique/Android studio/xmlPython/donnees.json").readText()
    // Désérialisation du JSON en une Map<String, List<InformationWordByNature>>
    val mapOfWords: Map<String, List<InformationWordByNature>> = Json.decodeFromString(jsonString)
}



fun main() {
    val jsonString = File("/Users/laura/Documents/Informatique/Android studio/xmlPython/donnees.json").readText()


    // Désérialisation du JSON en une Map<String, List<InformationWordByNature>>
    val map: Map<String, List<InformationWordByNature>> = Json.decodeFromString(jsonString)

    println(map)
}
