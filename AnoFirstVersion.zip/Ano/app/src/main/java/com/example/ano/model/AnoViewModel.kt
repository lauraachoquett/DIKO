package com.example.ano.model

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.ano.dataSource.DataSourceFirstVersion.mapOfWords

import com.example.ano.dataSource.WordInfoF
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class AnoViewModel : ViewModel(){
    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()



    var currentWord by mutableStateOf("")
        private set
    var searchWord by mutableStateOf("")
        private set

    var infoCurrentWord: WordInfoF = WordInfoF(listOf("par défaut"),false)


    fun onFavoriteButtonClickedList(word:String) : Unit{
        updateCurrentWord(word)
        if (isFavoriteWord(currentWord)) {
            return deleteOfFavorites()
        } else {
            addToFavorites()
        }

    }

    fun onFavoriteButtonClicked() :Unit {
        if (isFavoriteWord(currentWord)) {
            return deleteOfFavorites()
        } else {
            addToFavorites()
        }
    }

    private fun addToFavorites() {
        mapOfWords[currentWord]?.isFavorite = true
        _uiState.update { currentState ->
            val updatedFavorites = listOf(currentWord) + currentState.favorites.orEmpty()
            currentState.copy(
                favorites = updatedFavorites,
                wordsInHistory = currentState.wordsInHistory
            )
        }
    }


    private fun deleteOfFavorites(){
        mapOfWords[currentWord]?.isFavorite = false
        _uiState.update { currentState ->
            currentState.copy(
                favorites = currentState.favorites?.filter { it != currentWord },
                wordsInHistory = currentState.wordsInHistory
            )
        }
    }

    fun addToHistory(word: String) {
        _uiState.update { currentState ->
            currentState.copy(
                favorites = currentState.favorites,
                wordsInHistory = listOf(word) + currentState.wordsInHistory.orEmpty()
            )
        }
    }

    fun updateSearchedWord(word:String){
        searchWord = word
    }

    fun updateCurrentWord(word:String){
        currentWord = word
    }

    fun definitionOfTheWord(word:String){
       infoCurrentWord = mapOfWords[currentWord]!!
    }

    fun isWordInDico() :Boolean{
        return mapOfWords.containsKey(currentWord.trim())
    }

    fun isFavoriteWord (word : String): Boolean{
        return mapOfWords[word]?.isFavorite ?: false
    }

    fun onKeyboardSearch() {
        updateCurrentWord(searchWord.trim())
        if (isWordInDico()) {
            addToHistory(currentWord)
            definitionOfTheWord(currentWord)
            searchWord = ""
        }
        else{
            currentWord=""
        }
    }

    fun onWordClicked(word : String){
        updateCurrentWord(word)
        definitionOfTheWord(currentWord)
        addToHistory(word)
    }



}

