package com.example.ano.model


data class UiState(
    val favorites: List<String>? = null,
    val wordsInHistory: List<String> ?= null,
    )