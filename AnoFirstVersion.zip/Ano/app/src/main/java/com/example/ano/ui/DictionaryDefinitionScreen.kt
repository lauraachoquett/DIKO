package com.example.ano.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ano.R
import com.example.ano.dataSource.DataSourceFirstVersion
import com.example.ano.dataSource.WordInfoF
import com.example.readinggoals.ui.theme.Barlow

@Composable
fun DictionaryDefinitionScreen(
    isFavorite : (String)-> Boolean,
    word : String,
    wordInfos : WordInfoF,
    onFavoriteButtonClicked : ()->Unit,
){
    var isFavoriteState by remember { mutableStateOf(isFavorite(word)) }
    Column(
        verticalArrangement = Arrangement.Top,
        modifier = Modifier.padding(8.dp)
    ){
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ){
            Text(
                text = word,
                fontFamily = Barlow,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp
            )
            Spacer(modifier = Modifier.weight(1f))
            IconButton(onClick = {
                onFavoriteButtonClicked()
                // Met à jour l'état local de l'icône
                isFavoriteState = !isFavoriteState
            }) {
                Icon(
                    painter = painterResource(id = if(isFavoriteState) R.drawable.round_star_24 else R.drawable.round_star_outline_24),
                    contentDescription = null,
                )
            }
        }
        var i =1
        for (definition in  wordInfos.definitions){
            Row(
            ){
                Text(
                    text = "$i",
                    fontWeight = FontWeight.Normal,
                    modifier = Modifier.padding(2.dp)
                )
                Text(
                    text = definition,
                    fontWeight = FontWeight.Normal,
                    fontSize = 20.sp,
                    lineHeight = 24.sp,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(8.dp)
                )
            }
            i+=1
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DictionaryDefinitionPreview() {
    DataSourceFirstVersion.mapOfWords["affre"]?.let {
        DictionaryDefinitionScreen(isFavorite = {true}, word = "affre",wordInfos = it,
        onFavoriteButtonClicked = {}
    )
    }
}
        

