package com.example.ano.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ano.R
import com.example.readinggoals.ui.theme.Barlow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DictionarySearchingScreen(
    searchWord : String,
    onUserSearchedChanged: (String) -> Unit,
    onKeyboardSearch: () -> Unit,
    modifier : Modifier = Modifier,
){

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top,
        modifier = Modifier.fillMaxSize()
    ){
        Spacer(modifier = Modifier.height(64.dp))
        Image(
            painter = painterResource(id =R.drawable.search_image ),
            contentDescription = null,
            modifier = modifier
                .padding(16.dp)
                .clip(RoundedCornerShape(8.dp))

        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ){
            TextField(
                value = searchWord,
                trailingIcon = {
                    IconButton(onClick = onKeyboardSearch) {
                        Icon(
                            painter = painterResource(id = R.drawable.round_search_24),
                            null
                        )
                    }
                },
                onValueChange = onUserSearchedChanged,
                placeholder = {
                    Text(
                        text = stringResource(id = R.string.searching),
                        fontFamily = Barlow,
                        fontWeight = FontWeight.Light,
                    )
                },
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Search
                ),
                keyboardActions = KeyboardActions(
                    onSearch = { onKeyboardSearch() }
                ),
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .fillMaxWidth(),
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomepagePreview(){
    //DictionarySearchingScreen(onValidateClicked = { /*TODO*/ })
}