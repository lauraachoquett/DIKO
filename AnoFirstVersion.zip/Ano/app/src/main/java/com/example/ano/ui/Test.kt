package com.example.ano.ui

//@Composable
//fun TestScreen(info : WordInfo){
    //for (definition in info.definitions){
        //Text(text =definition)
  //  }
//}



